<?php
require "conn.php";
$Na1 = $_POST ["Na1"];
$Na2 =$_POST ["Na2"];
$Na3 =$_POST ["Na3"];
$C1 = $_POST["C1"];
$C2 = $_POST["C2"];
$C3 = $_POST["C3"];
$mysql_qry = "insert into data (Na1, Na2, Na3, C1, C2, C3) values('$Na1','$Na2','$Na3','$C1','$C2','$C3')";

if($conn->query($mysql_qry) === TRUE) {
echo "Data Insertion Successful";
}
else{
echo "Error:" . $mysql_qry. "<br>". $conn->error;
}
$conn->close();
?>
