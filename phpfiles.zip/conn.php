<?php
$db_name = "iste_201718";
$mysql_username = "iste";
$mysql_password = "Tech.18";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);
if($conn) {
echo "Connection Successful";
}
else {
echo "Connection Unsuccesful";
}
?>